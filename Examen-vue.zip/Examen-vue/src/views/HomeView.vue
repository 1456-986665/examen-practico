<template>
  <div class="home">
      <main class="main-content">
        <section class="hero">
          <h1>Bienvenido a Software Enviroment</h1>
          <p>Tu empresa más confible para el desarrollo tus softwares.</p>
        </section>
        <section class="about-us">
          <h2>Sobre Nosotros</h2>
          <p>
            Somos una empresa dedicada al desarrollo de software avanzado y 
            soluciones tecnológicas innovadoras. Nuestro equipo de profesionales 
            está comprometido con la excelencia en la satisfacción del cliente.   
          </p>
        </section>
        <section class="services">
          <h2>Nuestros Servicios:</h2>
          <ul>
            <li>Desarrollo de Software a Medida.</li>
            <li>Diseño de Experiencia de Usuario (UX/UI).</li>
            <li>Consultoría Tecnológica.</li>
            <li>Desarrollo de Aplicaciones Móviles.</li>
            <li>Desarrollo de Aplicaciones Web.</li>
            <li>Integración de Sistemas.</li>
            <li>Mantenimiento y Soporte.</li>
          </ul>
        </section>
        <section class="contact">
          <h2>Contacto:</h2>
          <p>Si tienes preguntaspuedes hacerlo contactandonos por medio
            de nustro correo electrónico.
            <br>
            infosoftware@enviroment.com
          </p>
          <a href="mailto:infosoftware@enviroment.com">infosoftware@enviroment.com</a>
        </section>
      </main>
  </div>
</template>

<script>
</script>

<style>

.home{
  width: 100%;
  text-align: center;
  align-items: center;
}

.header{
  color: #fff;
  text-align: center;
  width: 100%;
  height: 70px;
  position: fixed;
  left: 0;
  top: 0;
}

.main-content{
  margin-top: 100px;
  padding: 2rem;
  margin-top: 0px;
}

.main-content h1{
  font-size: 45px;
  color: black;
  padding: 20px;
}

.main-content p{
  font-size: 1rem
}

.services li, h2{
  color: black;
}
</style>