<template>
    <div class="acercaDe">
      <h1>Acerca de Software Enviroment</h1>
      <h3>Sobre Nosotros:</h3>
      <p>
        En Software Enviroment, estamos comprometidos en impulsar el cambio 
        a través de la innovación tecnológica. Fundada en [2000], nuestra
        empresa se ha convertido en un referente en el desarrollo de soluciones de software 
        de vanguardia que transforman la forma en que las organizaciones operan y prosperan 
        en el entorno empresarial actual.
      </p>
      <h3>Mision:</h3>
      <p>
        Nuestra misión es proporcionar soluciones de software de alto rendimiento y alta calidad que 
        permitan a nuestros clientes optimizar sus procesos, mejorar su eficiencia y alcanzar sus objetivos 
        comerciales de manera eficaz. Estamos comprometidos en ofrecer servicios excepcionales, desarrollar 
        productos innovadores y colaborar estrechamente con nuestros clientes para garantizar su éxito continuo.
      </p>
      <h3>Vision:</h3>
      <p>
        En Software Enviroment, aspiramos a ser líderes en la industria de la tecnología. Buscamos constantemente 
        la excelencia en la innovación, la calidad y el servicio al cliente. Nuestra visión es crear un mundo donde 
        la tecnología sea una fuerza impulsora que capacite a las organizaciones a superar sus desafíos y alcanzar nuevas
        alturas en su desarrollo.      
      </p>
      <h3>Nuestro Equipo:</h3>
      <p>
        En Software Enviroment, nuestro equipo está compuesto por profesionales altamente capacitados y apasionados por la tecnología.
         Nuestros ingenieros, diseñadores y expertos en desarrollo de software trabajan de manera colaborativa para crear soluciones personalizadas
         que se adapten a las necesidades específicas de nuestros clientes. Estamos orgullosos de contar con un equipo diverso y talentoso 
         que impulsa nuestra innovación y éxito continuo.
      </p>
      <h3>Contacto:</h3>
      <p>
        Si deseas conocer más acerca de nuestras soluciones o tienes alguna pregunta, no dudes en ponerte en contacto con nosotros. 
        Puedes enviarnos un correo electrónico a infosoftware@enviroment.com y uno de nuestros representantes estará encantado de atenderte.
<br>
       Gracias por considerar Software Enviroment como tu socio tecnológico. Estamos ansiosos por trabajar contigo y ayudarte a alcanzar tus objetivos empresariales.
      </p>
    </div>
  </template>
  
  <script>
  </script>

  <style>
    .acercaDe, p{
      text-align: center;
      font-size: 17px;
      padding: 12px;
    }

    .acercaDe{
      height: 800px;
      
    }

    h3{
      color: black;
    }
  </style>