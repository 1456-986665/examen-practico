<template>
    <header class="header">
      <h1>Software Enviroment</h1>
    </header>
  </template>
  
  <script>
  export default {
    // Lógica del componente si es necesario
  };
  </script>
  
  <style scoped>
  .header {
    background-color:  rgb(40, 42, 164);
    color: #fff;
    text-align: center;
    width: 100%;
    box-shadow: 1px 0px 3px 2px black;
  }
  
  .header h1 {
    color: #ece6e6;
    font-size: 24px;
    font-weight: bold;
    margin-top: -10px;
    font-family:'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
  }
  

  </style>
  