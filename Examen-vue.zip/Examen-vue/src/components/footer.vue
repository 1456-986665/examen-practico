<template>
  <footer class="footer">
    <p>Realizado por: Equipo de desarrollo especializado</p>
  </footer>
</template>

<style scoped>
.footer {
  background-color: rgb(40, 42, 164);
  color: #fff;
  text-align: center;
  padding: 10px;
  height: 70px;
  width: 100%;
  position: fixed; 
  bottom: 0; 
  left: 0;
}

p {
  color: #fff;
  padding: 10px;
}
</style>
